#pragma once

#include "lua.h"

void register_library(lua_State* state);