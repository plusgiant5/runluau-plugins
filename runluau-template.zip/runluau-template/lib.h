#pragma once

#include <lualib.h>

void register_library(lua_State* state);